# mu
A visual file manager

# Linux

Download Electron :
wget https://github.com/electron/electron/releases/download/v1.2.1/electron-v1.2.1-linux-x64.zip;

Download Mu :
wget https://github.com/smigniot/mu/archive/master.zip;

Unzip all in $ELECTRON and $MU and run :
$ELECTRON/electron $MU

# Usage

* Drag and drop a folder on the Mu screen
* Clic to shrink or expand a folder
* Use the search field at bottom to filter
* Selection with lasso to sum up files
* Simple clic to sum up all visible files
* Clic on green arcs to display image galleries

