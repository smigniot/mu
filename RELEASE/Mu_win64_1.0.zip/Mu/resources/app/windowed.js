function windowed(node) {
    var container = d3.select(node);
    var root = container.parent().append("g")
        .attr("class","window");
    
    // Not implemented yet
    // - add title bar
    // - allow resize
    // allow minimize left
}
